package com.example.Institute;

public class Department {
	String name, description;
	int id;
	College college;
	
	public Department(College college) {
	this.college = college;
	}
	
	public College getCollege() {
	return college;
	}
	public void setCollege(College college) {
	this.college = college;
	}
	public String getName() {
	return name;
	}
	public void setName(String name) {
	this.name = name;
	}
	public String getDescription() {
	return description;
	}
	public void setDescription(String
	description) {

	this.description = description;
	}
	public int getId() {
	return id;
	}
	public void setId(int id) {
	this.id = id;
	}

}
